package com.fitme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FitmeApplicationTests {

	@Test
	void contextLoads() {
	}

}
