package com.fitme.Repositoryes;

public abstract class DietRepository implements IDietRepository {

}
