package com.fitme.Repositoryes;

public abstract class Gymplan implements IGymPlanRepository {

}
