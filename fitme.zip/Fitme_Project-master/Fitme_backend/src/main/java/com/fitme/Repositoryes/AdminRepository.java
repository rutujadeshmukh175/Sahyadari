package com.fitme.Repositoryes;

abstract class AdminRepository implements IAdminRepository {

}
