package com.fitme.Repositoryes;

import javax.persistence.EntityManager;

public interface IMemberRepository {
    EntityManager getEntityManager();

}
